#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <cmath>
#include <stdlib.h>
#include <ctime>
#include <algorithm>
#include <list>
#include <QSignalBlocker>
#include <stdlib.h>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)

{
    ui->setupUi(this);
    maxslide = 200;
    coun = 0;
}

MainWindow::~MainWindow()
{
    delete ui;
    srand(time_t(nullptr)); //подключение рандома через реальное время
}

double MainWindow::randomgenerator(int min, int max)  //функция генерирования рандомных чисел
{
      double num = min + rand() % (max - min + 1); // Получить случайное число - формула
      num = num*(pow(-1,rand()%2+1)); // Получить случайный знак числа
      return num; //Возврат числа
}

void MainWindow::on_spinBox_valueChanged(int arg1) //Получение количества строк и столбцов таблицы
{
    coun = arg1;
    ui->tableWidget->setColumnCount(1); // Задаём один столбец
    ui->tableWidget->setRowCount(arg1); // Задаём строки
}

void MainWindow::on_tableWidget_itemChanged(QTableWidgetItem *item) //Функция проверки значений и изменения цвета ячейки
{
    QString text = item->text(); // Получаем текстовое значение ячейки
    bool flag;
    int value = text.toInt(&flag); // Пытаемся перевести строковое значение ячейки
    if(flag) //если перевод успешный
    {
        item->setForeground(Qt::black);
        item->setBackground(Qt::white); //фон белый
    }
    else if(abs(value) > 10e300) //если число огромное
    {
        item->setForeground(Qt::white);
        item->setBackground(Qt::red); //фон красный
    }
    else //если перевод не успешный
    {
        item->setForeground(Qt::white);
        item->setBackground(Qt::red); //фон красный
    }
}

void MainWindow::on_pushButton_clear_clicked() //Функция очистки полей
{
    ui->tableWidget->clear(); //Очистка таблицы
    ui->label_res->setText("Сумма: "); //Очистка вывода
}

void MainWindow::on_pushButton_random_int_clicked() //Функция заполнения рандомными числами
{
    ui->tableWidget->blockSignals(true); //Отключаю сигналы таблицы чтобы ускорить процесс
    ui->tableWidget->clear(); //Очищаю таблицу, если она была заполнена
    int size = ui->tableWidget->rowCount(); //Получаю количество ячеек
    for(int i = 0; i < size; i++) //цикл заполнения (от i=0 до размера таблицы)
    {
        QTableWidgetItem *item = new QTableWidgetItem(QString::number(randomgenerator(0,maxslide))); //Создаю айтем с рандомным значением
        ui->tableWidget->setItem(i, 0, item); //Добавляю айтем в таблицу
    }
    ui->tableWidget->blockSignals(false); //Возвращаю сигналы для таблицы
}

void MainWindow::on_horizontalSlider_valueChanged(int value) //Функция изменения максимума рандома
{
    maxslide = value; //Значение от слайдера
}

void MainWindow::on_pushButton_search_clicked() // Нажатие кнопки "сумма"
{
    int *mas = new int[coun]; //Создаю динамический массив
    int size = ui->tableWidget->rowCount(); //Получаю число строк
    bool error = false; //флаг для ошибок
    if(mas != nullptr) //Проверка указателя
    {
        for(int i = 0; i < size; i++) //Цикл для создания массива из таблицы
        {
            QTableWidgetItem *item = ui->tableWidget->item(i,0); //Создаю айтем ячейки

            if(item == nullptr) //если айтем занулён
            {
                item = new QTableWidgetItem; //создаю новый айтем
                ui->tableWidget->setItem(i,0, item); //присваиваю в таблицу
            }
            QString text = item->text(); //получаю текст из айтема
            bool flag; //флаг проверки
            int value = text.toInt(&flag); //проверяю перевод в число
            if(flag) //если успешно
            {
                mas[i] = value; //присваиваю значение в массив
            }
            else
            {
                error = true; //иначе вывожу ошибку
            }
        }
        for(int i = 0; i<size; i++) //крашу в обычные цветвета таблицу
        {
            ui->tableWidget->item(i,0)->setForeground(Qt::black);
            ui->tableWidget->item(i,0)->setBackground(Qt::white);
        }
        if(coun == 0) //если размер таблицы 0
        {
            error = true; //то ошибка
        }
        if(error)//проверка флага
        {
            QMessageBox::information(this, "Ошибка", "Таблица заполнена некоректно");//вывод сообщения об ошибке
        }
        else//если ошибок нет
        {
            int size = ui->tableWidget->rowCount(); //число строк
            int suma = 0;
            ui->tableWidget->blockSignals(true);
            for(int i = 0; i < size; i++)
            {
                if(mas[i] % 2 == 0)
                    suma += mas[i];
            }
            ui->tableWidget->blockSignals(false);
            ui->label_res->setText("Сумма: "+QString::number(suma));
        }
    }
    delete [] mas; //освобождаю память
    mas = nullptr; //зануливаю указатель
}
