#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "QMessageBox"
#include <cmath>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_clicked()
{
    QString res, number_text, temp2;
    int temp1;
    bool fl;
    number_text = ui->lineEdit_num->text(); //введённое число
    temp1 = number_text.toInt(&fl, 16);
    if(fl)
    {
        if(temp1 < 0)
        {
            temp1 *= -1;
            temp2 = "-"+QString::number(temp1,8);
            ui->label_res->setText(temp2);
        }
        else
        {
        temp2 = QString::number(temp1,8);
        ui->label_res->setText(temp2);
        }
    }
    else
    {
        QMessageBox::warning(this,"Ошибка ввода","Некорректный ввод числа.\nЧисло должно быть целым шестнадцетиричным.\nВозможные символы: 0,1,2,3,4,5,6,\n,7,8,9,A,B,C,D,E,F (Алфавит латинский)");
    }
}


