#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "QIntValidator"
#include "QMessageBox"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->lineEdit->setValidator(new QIntValidator(this));
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_clicked()
{
    bool fl = false;
    unsigned long long num = ui->lineEdit->text().toULongLong(&fl);
    if(fl and num < 21)
        ui->label_res->setText(QString::number(fucktorial(num)));
    else
    {
        QMessageBox::warning(this,"Ошибка","Ошибка ввода числа. Введите целое\nположительное число меньше 20 включительно");
    }
}

unsigned long long MainWindow::fucktorial(unsigned long long num)
{
    if(num == 0)
        return(1);
    else
    {
        return(num*fucktorial(num-1));
    }
}
