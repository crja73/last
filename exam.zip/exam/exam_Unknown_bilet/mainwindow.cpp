#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_clicked()
{
    QPalette pal;
    pal = ui->lineEdit->palette();
    QString str = ui->lineEdit->text();
    if(str == "")
    {
        ui->label->setText("Пустая строка");
        pal.setColor(QPalette::Base,Qt::blue);
        pal.setColor(QPalette::Text,Qt::white);
        ui->lineEdit->setPalette(pal);
    }
    else
    {
        bool fl = false;
        int in = str.toInt(&fl);
        if(fl)
        {
            ui->label->setText("Целое число");
            pal.setColor(QPalette::Base,Qt::red);
            pal.setColor(QPalette::Text,Qt::white);
            ui->lineEdit->setPalette(pal);
        }
        else
        {
            fl = false;
            double du = str.toDouble(&fl);
            if(fl)
            {
                ui->label->setText("Вещественное число");
                pal.setColor(QPalette::Base,Qt::green);
                pal.setColor(QPalette::Text,Qt::white);
                ui->lineEdit->setPalette(pal);
            }
            else
            {
                ui->label->setText("Строка");
                pal.setColor(QPalette::Base,Qt::gray);
                pal.setColor(QPalette::Text,Qt::white);
                ui->lineEdit->setPalette(pal);
            }
        }
    }
}

void MainWindow::on_lineEdit_textChanged(const QString &arg1)
{
    ui->label->clear();
    QPalette pal;
    pal = ui->lineEdit->palette();
    pal.setColor(QPalette::Base,Qt::white);
    pal.setColor(QPalette::Text,Qt::black);
    ui->lineEdit->setPalette(pal);
}
