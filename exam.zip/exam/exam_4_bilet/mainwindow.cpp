#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <cmath>
#include <QMessageBox>


MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_res_clicked() //слот округления
{
    bool flag = false; //флаг проверки
    double num = ui->lineEdit->text().replace(",",".").toDouble(&flag); //входящее число
    if(flag) //проверка перевода в число
    {
        double deg = pow(10,ui->spinBox->value()); //10 в степени значения округления
        double res = round(num*deg)/deg; //число умножается на 10 в степени, округляется и делится после округления на 10 в степени
        ui->label_res->setText("Округление: "+QString::number(res)); //вывод результата
    }
    else //если ошибка перевода
    {
        QMessageBox::warning(this, "Ошибка 1", "Ошибка ввода числа. Число должно быть\nрациональным.");
    }

}

void MainWindow::on_pushButton_clicked() //слот очистки
{
    ui->label_res->clear();
    ui->label_res->setText("Округление: ");
    ui->spinBox->setValue(0);
    ui->lineEdit->clear();
}
