#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QTableWidgetItem>
#include <QMessageBox>
#include <algorithm>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

    double randomgenerator(int min, int max);

    void qsortRecursive(double *mas, int size);

    void randomsort(double *mas, int size);

    QString search_simple(double *mas, int size);

private slots:
    void on_tableWidget_itemChanged(QTableWidgetItem *item);

    void on_spinBox_valueChanged(int arg1);

    void on_pushButton_clear_clicked();

    void on_pushButton_random_int_clicked();

    void on_horizontalSlider_valueChanged(int value);

    void on_pushButton_search_clicked();

private:
    Ui::MainWindow *ui;

    int coun;

    int maxslide;
};

#endif // MAINWINDOW_H
